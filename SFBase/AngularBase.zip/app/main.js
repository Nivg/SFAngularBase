"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app_module_1 = require("./app.module");
angular.bootstrap(document, [
    app_module_1.appModule.name
]);
//# sourceMappingURL=main.js.map