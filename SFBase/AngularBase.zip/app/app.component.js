"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppComponent = (function () {
    function AppComponent() {
        this.cmpName = 'AppComponent';
    }
    return AppComponent;
}());
exports.appComponent = {
    controller: AppComponent,
    templateUrl: 'app/app.html'
};
//# sourceMappingURL=app.component.js.map