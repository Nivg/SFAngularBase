"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app_component_1 = require("./app.component");
var account_module_1 = require("./account/account.module");
exports.appModule = angular
    .module('app.module', [
    account_module_1.AccountModule.name
])
    .component('myApp', app_component_1.appComponent);
//# sourceMappingURL=app.module.js.map