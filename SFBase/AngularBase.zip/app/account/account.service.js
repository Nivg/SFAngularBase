"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var account_model_1 = require("./account.model");
var AccountService = (function () {
    function AccountService($q) {
        this.$q = $q;
    }
    AccountService.prototype.getAccount = function () {
        var p = new Promise(function (resolve, reject) {
            resolve(new account_model_1.AccountModel('Acc1', '054-9914567', 'Other', 'Acc1.com'));
        });
        return this.$q.when(p).then(// Log the fulfillment value
        function (val) {
            return val;
        })
            .catch(
        // Log the rejection reason
        function (reason) {
            console.log('Handle rejected promise (' + reason + ') here.');
        });
    };
    return AccountService;
}());
exports.AccountService = AccountService;
//# sourceMappingURL=account.service.js.map