"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountComponent = (function () {
    function AccountComponent(accountService) {
        this.accountService = accountService;
        this.loadAccount();
    }
    AccountComponent.prototype.loadAccount = function () {
        var _this = this;
        this.accountService
            .getAccount()
            .then(function (account) {
            //debugger;
            _this.account = account;
        });
    };
    AccountComponent.prototype.getAccount = function () {
        return this.account;
    };
    AccountComponent.prototype.addAccountView = function (accountView) {
        this.accountView = accountView;
    };
    AccountComponent.prototype.addAccountEdit = function (accountEdit) {
        this.accountEdit = accountEdit;
    };
    AccountComponent.prototype.editAccount = function () {
        this.accountEdit.isActive = true;
        this.accountView.isActive = false;
    };
    AccountComponent.prototype.cancelEditAccount = function () {
        this.accountEdit.isActive = false;
        this.accountView.isActive = true;
    };
    AccountComponent.prototype.saveAccount = function (isValid) {
        console.log('isValidForm::' + isValid);
        if (isValid) {
            this.accountEdit.isActive = false;
            this.accountView.isActive = true;
        }
    };
    return AccountComponent;
}());
exports.AccountComponent = AccountComponent;
exports.accountComponent = {
    controller: AccountComponent,
    templateUrl: 'app/account/account.html'
};
//# sourceMappingURL=account.component.js.map