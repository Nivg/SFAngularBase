"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by N.G on 15/04/2017.
 */
var AccountModel = (function () {
    function AccountModel(Name, Phone, Type, Website) {
        this.Name = Name;
        this.Phone = Phone;
        this.Type = Type;
        this.Website = Website;
    }
    return AccountModel;
}());
exports.AccountModel = AccountModel;
//# sourceMappingURL=account.model.js.map