"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountEditComponent = (function () {
    function AccountEditComponent() {
    }
    AccountEditComponent.prototype.$onInit = function () {
        this.accountCtrl.addAccountEdit(this);
        this.account = this.accountCtrl.getAccount();
        this.isActive = false;
    };
    return AccountEditComponent;
}());
exports.AccountEditComponent = AccountEditComponent;
exports.accountEditComponent = {
    controller: AccountEditComponent,
    bindings: {
        isActive: '<'
    },
    require: { accountCtrl: '^?account' },
    templateUrl: 'app/account/accountEdit.html'
};
//# sourceMappingURL=accountEdit.component.js.map