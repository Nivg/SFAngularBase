"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var account_component_1 = require("./account.component");
var account_service_1 = require("./account.service");
var accountView_component_1 = require("./accountView.component");
var accountEdit_component_1 = require("./accountEdit.component");
exports.AccountModule = angular
    .module('AccountModule', [])
    .component('account', account_component_1.accountComponent)
    .component('accountView', accountView_component_1.accountViewComponent)
    .component('accountEdit', accountEdit_component_1.accountEditComponent)
    .service('accountService', account_service_1.AccountService);
//# sourceMappingURL=account.module.js.map