"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AccountViewComponent = (function () {
    function AccountViewComponent() {
    }
    AccountViewComponent.prototype.$onInit = function () {
        this.accountCtrl.addAccountView(this);
        this.account = this.accountCtrl.getAccount();
        this.isActive = true;
    };
    return AccountViewComponent;
}());
exports.AccountViewComponent = AccountViewComponent;
exports.accountViewComponent = {
    controller: AccountViewComponent,
    bindings: {
        isActive: '<'
    },
    require: { accountCtrl: '^?account' },
    templateUrl: 'app/account/accountView.html'
};
//# sourceMappingURL=accountView.component.js.map